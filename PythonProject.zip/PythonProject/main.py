import socket

def avvia_client():
    host = '127.0.0.1'
    port = 65432

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    print("🎮 Benvenuto nel gioco 'Indovina il Calcolo'!")
    print("Rispondi a 10 domande. Digita 'exit' per uscire in qualsiasi momento.\n")

    try:
        for _ in range(10):
            domanda = client_socket.recv(1024).decode()
            print(domanda)

            risposta = input("La tua risposta: ")
            client_socket.send(risposta.encode())

            feedback = client_socket.recv(1024).decode()
            print(feedback)
            print("-" * 40)

        # Ricevi il messaggio finale
        messaggio_finale = client_socket.recv(1024).decode()
        print(messaggio_finale)

    except Exception as e:
        print(f"Errore: {e}")

    client_socket.close()

if __name__ == '__main__':
    avvia_client()

import socket
import random
import threading

def genera_domanda():
    operazioni = ['+', '-', '*', '/']
    num1 = random.randint(1, 10)
    num2 = random.randint(1, 10)
    operazione = random.choice(operazioni)

    # Evita la divisione per zero
    if operazione == '/':
        while num2 == 0:
            num2 = random.randint(1, 10)

    domanda = f"{num1} {operazione} {num2}"
    risultato = round(eval(domanda), 2)  # risultato arrotondato
    return domanda, risultato

def gestisci_cliente(client_socket, address):
    print(f"Connessione con {address} stabilita.")
    punteggio = 0
    numero_domande = 10

    for i in range(numero_domande):
        domanda, risultato = genera_domanda()
        client_socket.send(f"{i+1}/{numero_domande} - Indovina il risultato di: {domanda}".encode())

        try:
            risposta = client_socket.recv(1024).decode()
            if risposta.lower() == 'exit':
                break

            if float(risposta) == risultato:
                punteggio += 1
                client_socket.send(f"VVVVVV CORRETTO! Punteggio: {punteggio}".encode())
            else:
                punteggio -= 1
                client_socket.send(f"XXXXXXX SBAGLIATO! Era {risultato}. Punteggio: {punteggio}".encode())

        except Exception as e:
            print(f"Errore con il client {address}: {e}")
            break

    client_socket.send(f" Gioco finito! Il tuo punteggio finale è: {punteggio}".encode())
    client_socket.close()

def avvia_server():
    host = '127.0.0.1'
    port = 65432

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen()

    print(f"🎲 Server in ascolto su {host}:{port}...")

    while True:
        client_socket, address = server_socket.accept()
        threading.Thread(target=gestisci_cliente, args=(client_socket, address)).start()

if __name__ == '__main__':
    avvia_server()
